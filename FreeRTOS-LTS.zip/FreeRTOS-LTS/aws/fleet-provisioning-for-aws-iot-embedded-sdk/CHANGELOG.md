# Changelog for AWS IoT Fleet Provisioning Library

## v1.1.0 (October 2022)

### Updates
- [#26](https://github.com/aws/Fleet-Provisioning-for-AWS-IoT-embedded-sdk/pull/26) MISRA C:2012 Compliance Update
- [#25](https://github.com/aws/Fleet-Provisioning-for-AWS-IoT-embedded-sdk/pull/25) Update CBMC starter kit

## v1.0.1 (December 2021)

### Updates
 - [#20](https://github.com/aws/Fleet-Provisioning-for-AWS-IoT-embedded-sdk/pull/20) Update Doxygen version to 1.9.2

## v1.0.0 (August 2021)

This is the first release of the AWS IoT Fleet Provisioning Library.
